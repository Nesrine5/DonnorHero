# MyShop_Mac
This project is a rebuild of the eCommerce website built from my course Real World ASP.NET Development

[MVC Web Development](https://www.udemy.com/course/better-web-development-pro-techniques-for-success/?referralCode=08A1A0743AA31A4AD50A)

The original codebase for the course can be found here https://github.com/completecoder/MyShop

This version is the same code but rebuilt using Visual Studio for Mac.

For the backend database I used SQL Linux running in a docker container.

You can see how to build a development environment on your Mac here:
https://youtu.be/qSbdjQOcd6Q

For more details post a message on my Facebook page at https://www.facebook.com/completecloud.guru

Finally, checkout my blog at https://completecloud.guru
